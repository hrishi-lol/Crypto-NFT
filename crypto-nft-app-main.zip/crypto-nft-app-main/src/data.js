export const Icon_data = {
  icons: {
    crypto: require('./assets/icons/cryptocurrencies-inactive.png'),
    home: require('./assets/icons/home-inactive.png'),
    nft: require('./assets/icons/nft-inactive.png'),
    news: require('./assets/icons/news-inactive.png'),
    cryptofocused: require('./assets/icons/cryptocurrencies-active.png'),
    homefocused: require('./assets/icons/home-active.png'),
    nftfocused: require('./assets/icons/nft-active.png'),
    newsfocused: require('./assets/icons/news-active.png'),
  },
};

